<?php $__env->startSection('content'); ?>

<img src="<?php echo e(Storage::url('public/images/'. $wisata->image)); ?>" alt="" style="width: 500px">

<br><br>

<h5>Nama : <?php echo e($wisata->nama); ?></h5>
<h5>Kota : <?php echo e($wisata->kota); ?></h5>
<h5> Harga Tiket : <?php echo e($wisata->harga_tiket); ?></h5><br>

<a href="<?php echo e(route('wisatas.index')); ?>" class="btn btn-primary">Back</a>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('wisatas.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siswa/Desktop/app-wisata2/resources/views/wisatas/show.blade.php ENDPATH**/ ?>