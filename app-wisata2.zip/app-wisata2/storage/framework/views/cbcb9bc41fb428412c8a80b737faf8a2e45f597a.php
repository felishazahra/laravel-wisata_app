<?php $__env->startSection('content'); ?>

<form action="<?php echo e(route('wisatas.store')); ?>" method="post" enctype="multipart/form-data">
<?php echo csrf_field(); ?>

<label class="label-control">Image</label>
<input class="form-control" type="file" name="image"><br><br>

<label class="label-control">Nama</label>
<input class="form-control" type="text" name="nama"><br><br>

<label class="label-control">Kota</label>
<input class="form-control" type="text" name="kota"><br><br>

<label class="label-control">Harga Tiket</label>
<input class="form-control" type="number" name="harga_tiket"><br><br>

<input type="submit" value="Submit" class="btn btn-success">

</form>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('wisatas.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siswa/Desktop/app-wisata2/resources/views/wisatas/create.blade.php ENDPATH**/ ?>