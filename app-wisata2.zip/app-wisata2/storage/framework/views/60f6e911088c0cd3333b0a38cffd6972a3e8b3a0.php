<?php $__env->startSection('content'); ?>

<form action="<?php echo e(route('wisatas.update', $wisata->id)); ?>" method="post" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
<?php echo method_field('PUT'); ?>

<label class="label-control">Upload Image</label>
<input class="form-control" type="file" name="image"><br><br>

<label class="label-control">Nama</label>
<input class="form-control" type="text" name="nama" value="<?php echo e($wisata->nama); ?>"><br><br>

<label class="label-control">Kota</label>
<input class="form-control" type="text" name="kota" value="<?php echo e($wisata->kota); ?>"><br><br>

<label class="label-control">Harga Tiket</label>
<input class="form-control" type="number" name="harga_tiket" value="<?php echo e($wisata->harga_tiket); ?>"><br><br>

<input type="submit" value="Submit" class="btn btn-success">

</form>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('wisatas.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siswa/Desktop/app-wisata2/resources/views/wisatas/edit.blade.php ENDPATH**/ ?>