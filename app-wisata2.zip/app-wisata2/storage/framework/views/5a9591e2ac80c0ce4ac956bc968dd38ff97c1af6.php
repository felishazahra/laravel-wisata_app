<?php $__env->startSection('content'); ?>

<a class="btn btn-primary" href="<?php echo e(route('wisatas.create')); ?>">Add New</a>

<table class="table">
    <tr>
        <td>ID</td>
        <td>Image</td>
        <td>Nama</td>
        <td>Kota</td>
        <td>Harga Tiket</td>
        <td>Action</td>
    </tr>

    <?php $__currentLoopData = $wisatas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <tr>
        <td><?php echo e($w->id); ?></td>
        <td><img src="<?php echo e(Storage::url('public/images/'. $w->image)); ?>" alt="" style="width: 150px;"></td>
        <td><?php echo e($w->nama); ?></td>
        <td><?php echo e($w->kota); ?></td>
        <td><?php echo e($w->harga_tiket); ?></td>

        <td>
            <a class="btn btn-warning" href="<?php echo e(route('wisatas.show', $w->id)); ?>">Show</a>
            <a class="btn btn-success" href="<?php echo e(route('wisatas.edit', $w->id)); ?>">Edit</a>

            <form onclick="return confirm('Are You Sure?')"action="<?php echo e(route('wisatas.destroy',$w->id)); ?>" method="post" style="display:inline">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button class="btn btn-danger">Delete</button>
            </form>
        </td>
    </tr>
        
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

<?php echo e($wisatas->links()); ?>

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('wisatas.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/siswa/Desktop/app-wisata2/resources/views/wisatas/index.blade.php ENDPATH**/ ?>