@extends('wisatas.layout')

@section('content')

<img src="{{ Storage::url('public/images/'. $wisata->image) }}" alt="" style="width: 500px">

<br><br>

<h5>Nama : {{ $wisata->nama }}</h5>
<h5>Kota : {{ $wisata->kota }}</h5>
<h5> Harga Tiket : {{ $wisata->harga_tiket }}</h5><br>

<a href="{{ route('wisatas.index') }}" class="btn btn-primary">Back</a>
    
@endsection