@extends('wisatas.layout')

@section('content')

<a class="btn btn-primary" href="{{ route('wisatas.create') }}">Add New</a>

<table class="table">
    <tr>
        <td>ID</td>
        <td>Image</td>
        <td>Nama</td>
        <td>Kota</td>
        <td>Harga Tiket</td>
        <td>Action</td>
    </tr>

    @foreach ($wisatas as $w)

    <tr>
        <td>{{ $w->id }}</td>
        <td><img src="{{ Storage::url('public/images/'. $w->image) }}" alt="" style="width: 150px;"></td>
        <td>{{ $w->nama }}</td>
        <td>{{ $w->kota }}</td>
        <td>{{ $w->harga_tiket }}</td>

        <td>
            <a class="btn btn-warning" href="{{ route('wisatas.show', $w->id) }}">Show</a>
            <a class="btn btn-success" href="{{ route('wisatas.edit', $w->id) }}">Edit</a>

            <form onclick="return confirm('Are You Sure?')"action="{{route('wisatas.destroy',$w->id)  }}" method="post" style="display:inline">
            @csrf
            @method('DELETE')
            <button class="btn btn-danger">Delete</button>
            </form>
        </td>
    </tr>
        
    @endforeach
</table>

{{$wisatas->links()}}
    
@endsection