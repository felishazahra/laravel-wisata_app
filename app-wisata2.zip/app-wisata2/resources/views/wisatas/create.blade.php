@extends('wisatas.layout')

@section('content')

<form action="{{ route('wisatas.store') }}" method="post" enctype="multipart/form-data">
@csrf

<label class="label-control">Image</label>
<input class="form-control" type="file" name="image"><br><br>

<label class="label-control">Nama</label>
<input class="form-control" type="text" name="nama"><br><br>

<label class="label-control">Kota</label>
<input class="form-control" type="text" name="kota"><br><br>

<label class="label-control">Harga Tiket</label>
<input class="form-control" type="number" name="harga_tiket"><br><br>

<input type="submit" value="Submit" class="btn btn-success">

</form>
    
@endsection